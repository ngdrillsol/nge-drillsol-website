export interface CountryMarket {
  id: string;
  country: string;
  region: string;

  geology: string[];

  applications: string[];

  challenges: string[];

  rigRequirements: string[];

  recommendedRigs: string[];

  drillingMethods: string[];

  image: string;

  href: string;
}