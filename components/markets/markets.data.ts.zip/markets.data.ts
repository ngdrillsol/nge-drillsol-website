export const countryMarkets: CountryMarket[] = [
  {
    id: "kenya",
    country: "Kenya",
    region: "Africa",

    geology: [
      "Basalt",
      "Volcanic Rock",
      "Clay",
      "Sand",
    ],

    applications: [
      "Water Wells",
      "Agriculture",
      "Infrastructure",
    ],

    challenges: [
      "Hard volcanic formations",
      "Variable overburden",
      "Mixed soft and hard formations",
    ],

    rigRequirements: [
      "High torque rotary drilling",
      "DTH capability for hard rock",
      "Mud rotary capability for soft formations",
    ],

    recommendedRigs: [
      "NGDR2000",
      "NGDTH600R",
      "NGDR1500",
    ],

    drillingMethods: [
      "Mud Rotary",
      "DTH",
    ],

    image: "/images/markets/kenya.jpg",

    href: "/markets/africa/kenya",
  },

  {
    id: "south-africa",
    country: "South Africa",
    region: "Africa",

    geology: [
      "Granite",
      "Gneiss",
      "Basalt",
      "Sandstone",
      "Hard Rock",
    ],

    applications: [
      "Water Wells",
      "Mining",
      "Exploration",
      "Infrastructure",
    ],

    challenges: [
      "Hard crystalline formations",
      "Deep fractured rock",
      "Variable geological conditions",
    ],

    rigRequirements: [
      "High torque rotary system",
      "DTH capability for hard rock",
      "Strong mast and feed system",
    ],

    recommendedRigs: [
      "NGDTH600R",
      "NGDR2000",
      "NGCORE100",
    ],

    drillingMethods: [
      "DTH",
      "Mud Rotary",
      "Core Drilling",
    ],

    image: "/images/markets/south-africa.jpg",

    href: "/markets/africa/south-africa",
  },

  {
    id: "morocco",
    country: "Morocco",
    region: "Africa",

    geology: [
      "Limestone",
      "Sandstone",
      "Granite",
      "Metamorphic Rock",
      "Hard Rock",
    ],

    applications: [
      "Water Wells",
      "Agriculture",
      "Mining",
      "Infrastructure",
    ],

    challenges: [
      "Hard limestone formations",
      "Fractured rock",
      "Variable formation hardness",
    ],

    rigRequirements: [
      "High torque rotary drilling",
      "DTH capability in hard formations",
      "Controlled feed for fractured formations",
    ],

    recommendedRigs: [
      "NGDR2000",
      "NGDTH600R",
      "NGDR1500",
    ],

    drillingMethods: [
      "Mud Rotary",
      "DTH",
    ],

    image: "/images/markets/morocco.jpg",

    href: "/markets/africa/morocco",
  },

  {
    id: "egypt",
    country: "Egypt",
    region: "Africa",

    geology: [
      "Nubian Sandstone",
      "Limestone",
      "Alluvial Deposits",
      "Sand",
      "Basement Rock",
    ],

    applications: [
      "Water Wells",
      "Agriculture",
      "Industrial Water Supply",
      "Groundwater Development",
    ],

    challenges: [
      "Deep groundwater drilling",
      "Loose sand and alluvial formations",
      "Large depth requirements",
    ],

    rigRequirements: [
      "Deep drilling capability",
      "Mud rotary circulation",
      "High-capacity feed and hoisting system",
    ],

    recommendedRigs: [
      "NGDR3000",
      "NGDR2000",
      "NGDR1500",
    ],

    drillingMethods: [
      "Mud Rotary",
      "Rotary",
      "DTH",
    ],

    image: "/images/markets/egypt.jpg",

    href: "/markets/africa/egypt",
  },

  {
    id: "tanzania",
    country: "Tanzania",
    region: "Africa",

    geology: [
      "Granite",
      "Gneiss",
      "Volcanic Rock",
      "Basalt",
      "Sedimentary Rock",
    ],

    applications: [
      "Water Wells",
      "Mining",
      "Agriculture",
      "Infrastructure",
    ],

    challenges: [
      "Hard crystalline basement",
      "Volcanic formations",
      "Variable overburden",
    ],

    rigRequirements: [
      "High torque drilling",
      "DTH capability for hard formations",
      "Mud rotary capability for overburden",
    ],

    recommendedRigs: [
      "NGDTH600R",
      "NGDR2000",
      "NGDR1500",
    ],

    drillingMethods: [
      "DTH",
      "Mud Rotary",
    ],

    image: "/images/markets/tanzania.jpg",

    href: "/markets/africa/tanzania",
  },
];