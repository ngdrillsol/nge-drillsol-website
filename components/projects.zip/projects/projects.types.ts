export interface Project {
  id: string;

  title: string;

  client: string;

  location: string;

  duration: string;

  image: string;

  description: string;

  drillingMethod: string;

  application: string;

  rigs: string[];

  achievements: string[];

  gallery: string[];

  href: string;
}

export interface ProjectMilestone {
  title: string;

  description: string;

  date: string;
}