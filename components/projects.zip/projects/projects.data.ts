import { Project } from "./projects.types";

export const projects: Project[] = [
  {
    id: "adani-green-hydrogen",

    title: "Adani Green Hydrogen Project",

    client: "Adani Green Energy Ltd.",

    location: "Suigam, Gujarat, India",

    duration: "February 2024 – June 2024",

    image: "/images/projects/adani-hero.jpg",

    description:
      "Groundwater investigation and deep water well drilling for one of the world's largest Green Hydrogen developments. The project required drilling under extremely challenging geological conditions while achieving high groundwater yield and acceptable water quality.",

    drillingMethod: "Mud Rotary Drilling",

    application: "Green Hydrogen Infrastructure",

    rigs: [
      "NGDR1500",
      "Laxmi 7x10 Mud Pump",
      "Atlas Copco Compressor",
    ],

    achievements: [
      "Successfully completed groundwater investigation",
      "Deep drilling in extremely hard formations",
      "Supported India's Green Hydrogen Mission",
      "High groundwater yield achieved",
    ],

    gallery: [
      "/images/projects/adani-1.jpg",
      "/images/projects/adani-2.jpg",
      "/images/projects/adani-3.jpg",
    ],

    href: "/projects/adani-green-hydrogen",
  },

  {
    id: "khavda-renewable-energy-park",

    title: "Khavda Renewable Energy Park",

    client: "Renewable Energy Infrastructure",

    location: "Khavda, Gujarat, India",

    duration: "Ongoing",

    image: "/images/projects/khavda.jpg",

    description:
      "Foundation drilling solutions for one of the world's largest renewable energy developments using the NGDP Series piling rigs.",

    drillingMethod: "Foundation Drilling",

    application: "Solar Infrastructure",

    rigs: [
      "NGDP15",
      "NGDP30",
      "NGDP60",
    ],

    achievements: [
      "Reliable foundation drilling",
      "High productivity",
      "Successful execution in demanding site conditions",
    ],

    gallery: [
      "/images/projects/khavda-1.jpg",
      "/images/projects/khavda-2.jpg",
    ],

    href: "/projects/khavda-renewable-energy",
  },
];