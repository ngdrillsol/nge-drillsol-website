import { Industry } from "./industries.types";

export const industries: Industry[] = [
  {
    id: "water-supply",

    title: "Water Supply",

    description:
      "Reliable drilling solutions for municipal water supply, rural drinking water schemes, commercial water wells and deep groundwater development.",

    icon: "💧",

    image: "/images/industries/water-supply.jpg",

    applications: [
      "Municipal Water Supply",
      "Rural Water Schemes",
      "Commercial Borewells",
      "Industrial Water Supply",
    ],

    geology: [
      "Clay",
      "Sand",
      "Gravel",
      "Basalt",
      "Granite",
    ],

    recommendedRigs: [
      "NGDR3000",
      "NGDR2000",
      "NGDR1500",
      "NGDR1000",
    ],

    href: "/industries/water-supply",
  },

  {
    id: "agriculture",

    title: "Agriculture & Irrigation",

    description:
      "Efficient drilling rigs for irrigation borewells, agricultural water supply and groundwater development for farming applications.",

    icon: "🌾",

    image: "/images/industries/agriculture.jpg",

    applications: [
      "Irrigation",
      "Farm Water Supply",
      "Tube Wells",
      "Groundwater Development",
    ],

    geology: [
      "Clay",
      "Sand",
      "Gravel",
    ],

    recommendedRigs: [
      "NGDR1500",
      "NGDR1000",
      "NGDTH300R",
    ],

    href: "/industries/agriculture",
  },

  {
    id: "mining",

    title: "Mining",

    description:
      "Drilling solutions for mineral exploration, production drilling, blast hole drilling and mining support operations.",

    icon: "⛏",

    image: "/images/industries/mining.jpg",

    applications: [
      "Mineral Exploration",
      "Blast Hole Drilling",
      "Mine Development",
    ],

    geology: [
      "Granite",
      "Basalt",
      "Hard Rock",
    ],

    recommendedRigs: [
      "NGDTH600R",
      "NGDTH450R",
      "NGCORE100",
    ],

    href: "/industries/mining",
  },

  {
    id: "infrastructure",

    title: "Infrastructure",

    description:
      "Foundation drilling solutions for bridges, highways, transmission lines, commercial buildings and civil engineering projects.",

    icon: "🏗",

    image: "/images/industries/infrastructure.jpg",

    applications: [
      "Bridge Foundations",
      "Highways",
      "Commercial Construction",
      "Transmission Towers",
    ],

    geology: [
      "Mixed Formations",
      "Hard Rock",
    ],

    recommendedRigs: [
      "NGDP60",
      "NGDP30",
      "NGDP15",
    ],

    href: "/industries/infrastructure",
  },

  {
    id: "solar",

    title: "Solar",

    description:
      "Pile foundation drilling solutions for utility-scale solar parks, renewable energy projects and photovoltaic installations.",

    icon: "☀",

    image: "/images/industries/solar.jpg",

    applications: [
      "Solar Parks",
      "PV Foundations",
      "Renewable Energy",
    ],

    geology: [
      "Clay",
      "Sand",
      "Gravel",
      "Hard Rock",
    ],

    recommendedRigs: [
      "NGDP60",
      "NGDP30",
      "NGDP15",
    ],

    href: "/industries/solar",
  },

  {
    id: "oil-gas",

    title: "Oil & Gas",

    description:
      "Heavy-duty drilling equipment and workover rigs for upstream oilfield support and energy sector operations.",

    icon: "🛢",

    image: "/images/industries/oil-gas.jpg",

    applications: [
      "Workover Operations",
      "Oilfield Services",
      "Energy Projects",
    ],

    geology: [
      "Sedimentary Rock",
      "Sandstone",
      "Limestone",
    ],

    recommendedRigs: [
      "NGWR3100",
    ],

    href: "/industries/oil-gas",
  },

  {
    id: "geological-exploration",

    title: "Geological Exploration",

    description:
      "Core drilling systems for geological mapping, geotechnical investigation, mineral exploration and scientific studies.",

    icon: "🧪",

    image: "/images/industries/geological-exploration.jpg",

    applications: [
      "Core Sampling",
      "Geotechnical Investigation",
      "Mineral Exploration",
    ],

    geology: [
      "All Geological Formations",
    ],

    recommendedRigs: [
      "NGCORE100",
      "NGCORE50",
    ],

    href: "/industries/geological-exploration",
  },
];