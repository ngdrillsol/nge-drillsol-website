"use client";

import Container from "@/components/ui/container";
import Section from "@/components/ui/section";

import TrustHeader from "./TrustHeader";
import CertificationGrid from "./CertificationGrid";

export default function TrustSection() {
  return (
    <Section
      id="trust"
      className="relative overflow-hidden bg-[#05070B]"
    >
      {/* Background */}

      <div className="absolute inset-0 overflow-hidden">

        <div className="absolute left-1/2 top-0 h-[700px] w-[700px] -translate-x-1/2 rounded-full bg-yellow-500/5 blur-[180px]" />

        <div className="absolute right-0 bottom-0 h-[450px] w-[450px] rounded-full bg-purple-600/5 blur-[180px]" />

      </div>

      <Container className="relative z-10">

        <TrustHeader />

        <CertificationGrid />

        {/* Bottom Statement */}

        <div className="mx-auto mt-20 max-w-4xl rounded-[32px] border border-white/10 bg-white/[0.03] px-10 py-12 text-center">

          <h3 className="text-3xl font-bold text-white">
            Engineering Confidence for Every Project
          </h3>

          <p className="mt-6 text-lg leading-8 text-slate-400">
            From engineering design and precision manufacturing to global
            delivery and after-sales support, every NGE Drillsol solution is
            developed with a commitment to quality, reliability and long-term
            customer success.
          </p>

        </div>

      </Container>

    </Section>
  );
}