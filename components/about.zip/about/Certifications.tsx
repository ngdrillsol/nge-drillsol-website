"use client";

import { motion } from "framer-motion";
import {
  BadgeCheck,
  Award,
  ShieldCheck,
  CheckCircle2,
} from "lucide-react";

import { certifications } from "./about.data";

export default function Certifications() {
  return (
    <section className="space-y-16">

      {/* Heading */}

      <div className="text-center">

        <span className="rounded-full border border-yellow-500/30 bg-yellow-500/10 px-5 py-2 text-xs font-semibold uppercase tracking-[0.35em] text-yellow-400">
          Certifications & Recognition
        </span>

        <h2 className="mt-6 text-5xl font-bold text-white">
          Built On
          <span className="block text-yellow-400">
            Quality & Compliance
          </span>
        </h2>

        <p className="mx-auto mt-6 max-w-3xl text-lg leading-8 text-slate-400">
          Our commitment to engineering quality is supported by recognized
          certifications and industry standards that reinforce our focus on
          dependable manufacturing and customer confidence.
        </p>

      </div>

      {/* Certification Grid */}

      <div className="grid gap-8 md:grid-cols-2 xl:grid-cols-5">

        {certifications.map((certificate, index) => (

          <motion.div
            key={certificate.title}
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.08 }}
            whileHover={{ y: -6 }}
            className="rounded-[30px] border border-white/10 bg-[#090909] p-8 text-center transition-all duration-300 hover:border-yellow-500/30"
          >

            <div className="flex h-32 items-center justify-center rounded-2xl border border-white/10 bg-white/5">

              {certificate.image ? (
                <img
                  src={certificate.image}
                  alt={certificate.title}
                  className="max-h-20 object-contain"
                />
              ) : (
                <Award
                  size={60}
                  className="text-yellow-400"
                />
              )}

            </div>

            <h3 className="mt-6 text-xl font-bold text-white">
              {certificate.title}
            </h3>

          </motion.div>

        ))}

      </div>

      {/* Bottom Features */}

      <div className="grid gap-8 md:grid-cols-3">

        <div className="rounded-[30px] border border-white/10 bg-[#090909] p-8 text-center">

          <BadgeCheck
            size={42}
            className="mx-auto text-yellow-400"
          />

          <h3 className="mt-6 text-2xl font-bold text-white">
            Quality Standards
          </h3>

          <p className="mt-4 leading-8 text-slate-400">
            Engineering processes focused on dependable manufacturing and
            consistent product quality.
          </p>

        </div>

        <div className="rounded-[30px] border border-white/10 bg-[#090909] p-8 text-center">

          <ShieldCheck
            size={42}
            className="mx-auto text-yellow-400"
          />

          <h3 className="mt-6 text-2xl font-bold text-white">
            Customer Confidence
          </h3>

          <p className="mt-4 leading-8 text-slate-400">
            Certifications help reinforce our commitment to quality,
            reliability and professional engineering practices.
          </p>

        </div>

        <div className="rounded-[30px] border border-white/10 bg-[#090909] p-8 text-center">

          <CheckCircle2
            size={42}
            className="mx-auto text-yellow-400"
          />

          <h3 className="mt-6 text-2xl font-bold text-white">
            Continuous Improvement
          </h3>

          <p className="mt-4 leading-8 text-slate-400">
            We continuously improve our products and processes to meet
            evolving customer expectations and industry requirements.
          </p>

        </div>

      </div>

    </section>
  );
}